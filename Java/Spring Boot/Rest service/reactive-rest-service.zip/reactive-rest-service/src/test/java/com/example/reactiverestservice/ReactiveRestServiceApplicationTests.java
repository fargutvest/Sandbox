package com.example.reactiverestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
