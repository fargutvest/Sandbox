/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM e:/builds/moz2_slave/mozilla-1.9.2-win32-xulrunner/build/embedding/components/webbrowserpersist/public/nsCWebBrowserPersist.idl
 */

#ifndef __gen_nsCWebBrowserPersist_h__
#define __gen_nsCWebBrowserPersist_h__


#ifndef __gen_nsIWebBrowserPersist_h__
#include "nsIWebBrowserPersist.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// {7E677795-C582-4cd1-9E8D-8271B3474D2A}
#define NS_WEBBROWSERPERSIST_CID \
{ 0x7e677795, 0xc582, 0x4cd1, { 0x9e, 0x8d, 0x82, 0x71, 0xb3, 0x47, 0x4d, 0x2a } }
#define NS_WEBBROWSERPERSIST_CONTRACTID \
"@mozilla.org/embedding/browser/nsWebBrowserPersist;1"

#endif /* __gen_nsCWebBrowserPersist_h__ */
