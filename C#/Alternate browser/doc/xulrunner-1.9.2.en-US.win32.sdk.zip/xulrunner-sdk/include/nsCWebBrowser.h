/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM e:/builds/moz2_slave/mozilla-1.9.2-win32-xulrunner/build/embedding/browser/webBrowser/nsCWebBrowser.idl
 */

#ifndef __gen_nsCWebBrowser_h__
#define __gen_nsCWebBrowser_h__


#ifndef __gen_nsIWebBrowser_h__
#include "nsIWebBrowser.h"
#endif

#ifndef __gen_nsIBaseWindow_h__
#include "nsIBaseWindow.h"
#endif

#ifndef __gen_nsIScrollable_h__
#include "nsIScrollable.h"
#endif

#ifndef __gen_nsITextScroll_h__
#include "nsITextScroll.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsEmbedCID.h"

#endif /* __gen_nsCWebBrowser_h__ */
